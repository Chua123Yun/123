package ZZZZ;

public interface Interface {

    public String deleteItem(String itemName, double itemWeight, int itemQuantity, double itemValue);

    public void addToMap(String itemName, double itemWeight, int itemQuantity, double itemValue);

    public void printItems(); //  print all the map values 

    public int mapSize(); //check map size for n in all the algorithm 
}